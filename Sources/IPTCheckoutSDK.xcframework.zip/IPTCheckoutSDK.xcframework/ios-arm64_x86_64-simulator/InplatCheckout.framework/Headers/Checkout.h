//
//  Checkout.h
//  Checkout
//
//  Created by Иван Ерасов on 21.12.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for Checkout.
FOUNDATION_EXPORT double CheckoutVersionNumber;

//! Project version string for Checkout.
FOUNDATION_EXPORT const unsigned char CheckoutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Checkout/PublicHeader.h>


