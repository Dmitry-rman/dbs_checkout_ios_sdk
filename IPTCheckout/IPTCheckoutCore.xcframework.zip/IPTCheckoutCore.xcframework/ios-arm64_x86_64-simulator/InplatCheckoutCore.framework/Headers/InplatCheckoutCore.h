//
//  InplatCheckoutCore.h
//  InplatCheckoutCore
//
//  Created by Иван Ерасов on 23.12.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for InplatCheckoutCore.
FOUNDATION_EXPORT double InplatCheckoutCoreVersionNumber;

//! Project version string for InplatCheckoutCore.
FOUNDATION_EXPORT const unsigned char InplatCheckoutCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InplatCheckoutCore/PublicHeader.h>


